#!/bin/sh
############################################################
#
#get_fork.sh
#
#get a second branch to work in parallel
#because we can not simple merge
#
#Lutz Scheffler 2023-09-03
#
############################################################

#create a new remote to fork lscheffler
git remote add sf git@github.com:lscheffler/foxbin2prg.git
#read lscheffler
git fetch sf

#create a new branch "lutz" and switch into it
git switch -c lutz
#reset this branch to the last common anchestor between lscheffler/fork_mod and fdbozzo/master
git reset --hard c31b8106652

#connect the new branch with lscheffler/fork_mod
git branch --set-upstream-to=sf/fork_mod lutz
#set branch to top of his remote branch
git pull

#switch back to master
git switch master
#create a new folder on drive, that shows the lscheffler data
git worktree add ../FoxBin2Prg_Lutz lutz

#you can now work in the one and in the other directory
#that means you can copy files from the one to the other via normal function
#or you can pick data from the one to the other like

#for example FoxBin2Prg.prg
#git checkout lutz FoxBin2Prg.prg

#the file is not in the index, you can alter and then add and commit